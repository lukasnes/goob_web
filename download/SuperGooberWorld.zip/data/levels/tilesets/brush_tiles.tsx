<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="brush_tiles" tilewidth="64" tileheight="64" tilecount="5" columns="5">
 <image source="../../PixelArt/brush/brush_tiles.png" width="320" height="64"/>
</tileset>
