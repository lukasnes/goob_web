<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="enemy_tiles" tilewidth="64" tileheight="64" tilecount="10" columns="5">
 <image source="../../PixelArt/enemy/enemy_tiles.png" width="320" height="128"/>
</tileset>
