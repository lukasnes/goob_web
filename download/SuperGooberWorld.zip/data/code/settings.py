vertical_tiles = 12
tile_size = 64

screen_height = vertical_tiles * tile_size
screen_width = 1280